-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2025 at 04:30 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `contact` char(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `profile_picture` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `registered_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `first_name`, `last_name`, `contact`, `gender`, `email`, `password`, `profile_picture`, `address`, `registered_at`) VALUES
(3, 'moham', 'asi', '9876756788', 'Male', 'admin@gmail.com', 'Admin@1234', '', '', '2025-05-17 01:58:20');

-- --------------------------------------------------------

--
-- Table structure for table `create_ticket`
--

CREATE TABLE `create_ticket` (
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `task_type` varchar(50) NOT NULL,
  `priority` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `response` text NOT NULL,
  `raised_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `create_ticket`
--

INSERT INTO `create_ticket` (`ticket_id`, `user_id`, `subject`, `task_type`, `priority`, `description`, `response`, `raised_at`) VALUES
(1, 5, 'sdf', 'technical issue', 'Important', 'this is myy description i need it for a further job', 'hi how are you', '2025-04-07 01:02:30'),
(2, 4, 'sfd', 'services issue', 'Urgent functional problem', 'gd', 'gd response', '2025-04-07 01:28:24'),
(3, 5, 'gh', 'technical issue', 'Important', 'gfh', 'dfgg', '2025-04-07 01:41:38'),
(4, 5, 'fds', 'renewal', 'Important', 'bv', 'gh', '2025-05-17 02:23:59');

-- --------------------------------------------------------

--
-- Table structure for table `request_quote`
--

CREATE TABLE `request_quote` (
  `request_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` char(10) NOT NULL,
  `company` varchar(200) NOT NULL,
  `service_required` text NOT NULL,
  `description` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `remark` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `request_quote`
--

INSERT INTO `request_quote` (`request_id`, `first_name`, `last_name`, `email`, `contact`, `company`, `service_required`, `description`, `user_id`, `remark`, `created_at`) VALUES
(2, 'fg', 'gfd', 'dfg@gmail.com', '9446456456', 'fabhost', 'Ecommerce Developement,Domain Registration,Web Hosting Services', 'ghfgh', 5, 'hi', '2025-04-03 01:27:10'),
(3, 'sf', 'sf', 'sdf@gmail.com', '9675756575', 'gfdf', 'CMS (content Managment System),Website Maintainance,Ecommerce Developement', 'dfg', 3, 'this is my remark', '2025-04-03 01:26:26'),
(4, 'as', 'as', 'as@gmail.com', '9999999999', 'dff', 'SEO (Search Engine Optimization)', 'bv', 5, '', '2025-05-17 02:15:50');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `contact` char(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `profile_picture` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `registered_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `contact`, `gender`, `email`, `password`, `profile_picture`, `address`, `registered_at`) VALUES
(3, 'sandhiya', 'k', '9644564564', 'Female', 'sandhiya@gmail.com', 'Test@12345', '', '', '2025-03-12 00:55:07'),
(4, 'kajal', 'agarwal', '9573141111', 'Female', 'kajal@gmail.com', 'Kajal@123', '', '', '2025-03-12 01:03:29'),
(5, 'ganeshs', 'kumars', '9278545344', 'Male', 'ganesh@gmail.com', 'Ganesh@123', '', '', '2025-03-22 02:40:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `create_ticket`
--
ALTER TABLE `create_ticket`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `request_quote`
--
ALTER TABLE `request_quote`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `create_ticket`
--
ALTER TABLE `create_ticket`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `request_quote`
--
ALTER TABLE `request_quote`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
