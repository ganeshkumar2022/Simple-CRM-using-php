<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CRM Software - Register</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-6 d-none d-lg-block bg-register-image">
                        <img src="img/bg1.avif" class="w-100 h-100">
                    </div>
                    <div class="col-lg-6">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                            </div>
                            <form class="user" method="post" autocomplete="off" id="register_form">
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control form-control-user" id="first_name" name="first_name"
                                            placeholder="First Name">
                                        <span class="text-danger first_name_err"></span>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control form-control-user" id="last_name" name="last_name"
                                            placeholder="Last Name">
                                        <span class="text-danger last_name_err"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" id="email" name="email"
                                        placeholder="Email Address">
                                        <span class="text-danger email_err"></span>
                                </div>
                                <div class="form-group">
                                    <input type="text" onkeypress="return number_exist(event)" class="form-control form-control-user" id="contact" name="contact"
                                        placeholder="Contact no" maxlength="10">
                                        <span class="text-danger contact_err"></span>
                                </div>
                                <input type="hidden" name="cmd" id="cmd" value="user_register">
                                <div class="form-group">
                                    Gender : 
                                    <input type="radio" name="gender" value="Male"> Male&nbsp;&nbsp;
                                    <input type="radio" name="gender" value="Female"> Female&nbsp;&nbsp;
                                    <input type="radio" name="gender" value="Others"> Others&nbsp;&nbsp;
                                    <br><span class="text-danger gender_err"></span>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="password" class="form-control form-control-user"
                                            id="password" name="password" placeholder="Password">
                                            <span class="text-danger password_err"></span>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="password" class="form-control form-control-user"
                                            id="repeat_password" name="repeat_password" placeholder="Repeat Password">
                                            <span class="text-danger repeat_password_err"></span>
                                    </div>
                                </div>
                                <input type="submit" class="btn btn-primary btn-user btn-block" value="Register Account" name="register">
                                <hr>
                               
                            </form>
                            <div class="text-center">
                                <a class="small" href="index.php">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

<script>
    function number_exist(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
        return true; 
        }
        return false;
    }
    $(document).ready(function(){
        $("#register_form").submit(function(e){
            e.preventDefault();

            var first_name=$("#first_name").val();
            var last_name=$("#last_name").val();
            var email=$("#email").val();
            var gender=$("input[name='gender']:checked").val();
            var password=$("#password").val();
            var contact=$("#contact").val();
            var repeat_password=$("#repeat_password").val();
            var valid=true;
            var namepattern=/^[a-zA-Z\s]+$/;
            var emailpattern=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            var mobilepattern=/^\d{10}$/;
            const passwordPattern = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;



            //first name validation start
            if(first_name.length==0)
            {
               $(".first_name_err").text('Please enter First name');
               valid=false;   
            }
            else if(!namepattern.test(first_name))
            {
                $(".first_name_err").text('First name pattern not valid');
                valid=false;  
            }
            else
            {
                $(".first_name_err").text('');
            }
            //first name validation end

            //last name validation start
            if(last_name.length==0)
            {
               $(".last_name_err").text('Please enter Last name');
               valid=false;   
            }
            else if(!namepattern.test(last_name))
            {
                $(".last_name_err").text('Last name pattern not valid');
                valid=false;  
            }
            else
            {
                $(".last_name_err").text('');
            }
            //last name validation end

            //email validation start
            if(email.length==0)
            {
               $(".email_err").text('Please enter email');
               valid=false;   
            }
            else if(!emailpattern.test(email))
            {
                $(".email_err").text('Please enter valid email');
                valid=false;  
            }
            else
            {
                $(".email_err").text('');
            }
            //email validation end

            //contact validation start
            if(contact.length==0)
            {
               $(".contact_err").text('Please enter Mobile no');
               valid=false;   
            }
            else if(!mobilepattern.test(contact))
            {
                $(".contact_err").text('Please enter valid Mobile no');
                valid=false;  
            }
            else
            {
                $(".contact_err").text('');
            }
            //contact validation end

            //gender validation start
            if(gender==undefined)
            {
               $(".gender_err").text('Please choose gender');
               valid=false;   
            }
            else if(!namepattern.test(gender))
            {
                $(".gender_err").text('Not valid');
                valid=false;  
            }
            else
            {
                $(".gender_err").text('');
            }
            //gender validation end

            //password validation start
            if(password.length==0)
            {
               $(".password_err").text('Please enter password');
               valid=false;   
            }
            else if(!passwordPattern.test(password))
            {
                $(".password_err").text('password pattern not valid.atleast one uppercase,lowercase,digit and special character length is atleast 8');
                valid=false;  
            }
            else
            {
                $(".password_err").text('');
            }
            //password validation end

             //repeat_password validation start
             if(repeat_password.length==0)
            {
               $(".repeat_password_err").text('Please enter Confirm password');
               valid=false;   
            }
            else if(password!==repeat_password)
            {
                $(".repeat_password_err").text('password and confirm password not match');
                valid=false;  
            }
            else
            {
                $(".repeat_password_err").text('');
            }
            //repeat_password validation end


            if(valid)
            {
                $.ajax({
                    url:"db.php",
                    type:"POST",
                    data:$(this).serialize(),
                    dataType:'json',
                    success:function(response){
                        alert(response.message);
                        window.location.replace(window.location.href);
                        
                    },
                    error:function(xhr,status,response){
                        console.log(response);
                    }
                });
            }

        });
    });
</script>

</body>

</html>