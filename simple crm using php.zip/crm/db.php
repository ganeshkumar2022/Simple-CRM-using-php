<?php
session_start();
header("Content-type:application/json");


//db connect start

$servername="localhost";
$username="root";
$pass="";
$database="crm";
$str="mysql:host=$servername;dbname=$database";
try
{
    $con=new PDO($str,$username,$pass);
    //echo "Connected";
}
catch(PDOException $e)
{
    //echo "Error";
}

//db connect end

$cmd=$_REQUEST['cmd'];

if($_SERVER['REQUEST_METHOD']=="GET")
{
  if($cmd=="get_single_user")
  {
    $uid=$_GET['uid'];
    $sql4="select * from user where user_id=:uid";
    $result2=$con->prepare($sql4);
    $result2->bindParam(":uid",$uid);
    $result2->execute();
    $row2=$result2->fetch();
    echo json_encode($row2);    
  }
  if($cmd=="get_all_quotes")
  {
    $sql4="select * from request_quote order by request_id";
    $result2=$con->query($sql4);
    $result2->execute();
    $row2=$result2->fetchAll();
    echo json_encode($row2);    
  }
  if($cmd=="get_all_users")
  {
    $sql4="select * from user order by user_id";
    $result2=$con->query($sql4);
    $result2->execute();
    $row2=$result2->fetchAll();
    echo json_encode($row2);    
  }
  if($cmd=="get_one_quote")
  {
    $id=$_GET['id'];
    $sql4="select * from request_quote where request_id=:id";
    $result2=$con->prepare($sql4);
    $result2->bindParam(":id",$id);
    $result2->execute();
    $row2=$result2->fetch();
    echo json_encode($row2);    
  }
  if($cmd=="get_single_quote")
  {
    $id=$_GET['id'];
    $sql4="select * from request_quote where user_id=:id";
    $result2=$con->prepare($sql4);
    $result2->bindParam(":id",$id);
    $result2->execute();
    $row2=$result2->fetchAll();
    echo json_encode($row2);    
  }
  if($cmd=="get_single_admin")
  {
    $uid=$_GET['aid'];
    $sql4="select * from admin where user_id=:uid";
    $result2=$con->prepare($sql4);
    $result2->bindParam(":uid",$uid);
    $result2->execute();
    $row2=$result2->fetch();
    echo json_encode($row2);    
  }
  if($cmd=="view_user_ticket")
  {
    $uid=$_GET['uid'];
    $sql="select * from create_ticket where user_id=:uid";
    $result=$con->prepare($sql);
    $result->bindParam(":uid",$uid);
    $result->execute();
    $row=$result->fetchAll();
    echo json_encode($row);
  }
  if($cmd=="view_ticket")
  {
    $sql="select * from create_ticket a left join user b on a.user_id=b.user_id";
    $result=$con->query($sql);
    $result->execute();
    $row=$result->fetchAll();
    echo json_encode($row);
  }
  if($cmd=="view_one_ticket")
  {
    $id=$_GET['id'];
    $sql="select * from create_ticket a left join user b on a.user_id=b.user_id where a.ticket_id=:ticket_id";
    $result=$con->prepare($sql);
    $result->bindParam(":ticket_id",$id);
    $result->execute();
    $row=$result->fetchAll();
    echo json_encode($row);
  }
  if($cmd=="get_counts")
  {
    $uid=$_GET['uid'];
    $sql="SELECT *
FROM (
    SELECT 
        COUNT(request_id) AS all_quotes,
        user_id,
        COUNT(CASE WHEN remark='' THEN request_id END) AS pending_quotes
    FROM 
        request_quote 
    WHERE 
        user_id = :user_id
    GROUP BY 
        user_id
) a
LEFT JOIN (
    SELECT 
        COUNT(ticket_id) AS all_tickets,
        user_id,
        COUNT(CASE WHEN response='' THEN ticket_id END) AS pending_tickets
    FROM 
        create_ticket 
    WHERE 
        user_id = :user_id
    GROUP BY 
        user_id
) b ON a.user_id = b.user_id;
";
    $result=$con->prepare($sql);
    $result->bindParam(":user_id",$uid);
    $result->execute();
    $row=$result->fetch();
    echo json_encode($row);
  }


  //get counts admin start
  if($cmd=="get_counts_admin")
  {
    $sql="
    SELECT 
        coalesce(COUNT(request_id),0) AS all_quotes,
        coalesce(COUNT(CASE WHEN remark='' THEN request_id END),0) AS pending_quotes,
        0 as all_tickets,
        0 as pending_tickets

    FROM 
        request_quote 
    GROUP BY 
        user_id
UNION 
    SELECT
        0 as all_quotes,
        0 as pending_quotes,
        coalesce(COUNT(ticket_id),0) AS all_tickets,
        coalesce(COUNT(CASE WHEN response='' THEN ticket_id END),0) AS pending_tickets
    FROM 
        create_ticket
    GROUP BY 
        user_id

";
    $result=$con->query($sql);
    $result->execute();
    $row=$result->fetchAll();
    echo json_encode($row);
  }
  //get counts admin end

}
if($_SERVER['REQUEST_METHOD']=="POST")
{

  //create ticket start
  if($cmd=="create_ticket")
  {
    $subject=strip_tags($_POST['subject']);
    $task_type=strip_tags($_POST['task_type']);
    $priority=strip_tags($_POST['priority']);
    $description=strip_tags($_POST['description']);
    $user_id=$_SESSION['uid'];  


    $sql="insert into create_ticket (subject,task_type,priority,description,user_id) values (:subject,:task_type,:priority,:description,:user_id)";
    $result=$con->prepare($sql);
    $result->bindParam(":subject",$subject);
    $result->bindParam(":task_type",$task_type);
    $result->bindParam(":priority",$priority);
    $result->bindParam(":description",$description);
    $result->bindParam(":user_id",$user_id);

    try
    {
      $result->execute();
      echo json_encode(['status'=>'success','message'=>'Create ticket succcessfully']);
    }
    catch(Exception $e)
    {
      echo json_encode(['status'=>'error','message'=>'Error to Create ticket']);
    }
    
  }
  //create ticket end



  //quote_remark_update start
  if($cmd=="quote_remark_update")
  {
    $id=strip_tags($_POST['id']);
    $remark=strip_tags($_POST['remark']);

    $sql="update request_quote set remark=:remark where request_id=:request_id";
    $result=$con->prepare($sql);
    $result->bindParam(":remark",$remark);
    $result->bindParam(":request_id",$id);

    try
    {
      $result->execute();
      echo json_encode(['status'=>'success','message'=>'Remark added succcessfully']);
    }
    catch(Exception $e)
    {
      echo json_encode(['status'=>'error','message'=>'Error to add Remark']);
    }
    
  }
  //quote_remark_update end

    //ticket_response_update start
    if($cmd=="ticket_response_update")
    {
      $id=strip_tags($_POST['id']);
      $response=strip_tags($_POST['response']);
  
      $sql="update create_ticket set response=:response where ticket_id=:ticket_id";
      $result=$con->prepare($sql);
      $result->bindParam(":response",$response);
      $result->bindParam(":ticket_id",$id);
  
      try
      {
        $result->execute();
        echo json_encode(['status'=>'success','message'=>'Response added succcessfully']);
      }
      catch(Exception $e)
      {
        echo json_encode(['status'=>'error','message'=>'Error to add Response']);
      }
      
    }
    //ticket_response_update end


   //request quote start
   if($cmd=="request_quote")
   {
     $first_name=strip_tags($_POST['first_name']);
     $last_name=strip_tags($_POST['last_name']);
     $email=strip_tags($_POST['email']);
     $contact=strip_tags($_POST['contact']);
     $company=strip_tags($_POST['company']);
     $description=strip_tags($_POST['description']);
     $service_required=implode(",",$_POST['service_required']);
     $user_id=$_SESSION['uid'];  


     $sql="insert into request_quote (first_name,last_name,email,contact,company,service_required,description,user_id) values (:first_name,:last_name,:email,:contact,:company,:service_required,:description,:user_id)";
     $result=$con->prepare($sql);
     $result->bindParam(":first_name",$first_name);
     $result->bindParam(":last_name",$last_name);
     $result->bindParam(":email",$email);
     $result->bindParam(":contact",$contact);
     $result->bindParam(":company",$company);
     $result->bindParam(":service_required",$service_required);
     $result->bindParam(":description",$description);
     $result->bindParam(":user_id",$user_id);

     try
     {
       $result->execute();
       echo json_encode(['status'=>'success','message'=>'Request quote succcessfully']);
     }
     catch(Exception $e)
     {
       echo json_encode(['status'=>'error','message'=>'Error to Request quote']);
     }
     
   }
   //request quote end



     //update profile start
     if($cmd=="update_profile")
     {
       $first_name=strip_tags($_POST['first_name']);
       $last_name=strip_tags($_POST['last_name']);
       $email=strip_tags($_POST['email']);
       $contact=strip_tags($_POST['contact']);
       $gender=strip_tags($_POST['gender']);
       $uid=$_SESSION['uid'];
       
       //check email exist start
       $sql4="select * from user where email=:email and user_id!=:uid";
       $result2=$con->prepare($sql4);
       $result2->bindParam(":email",$email);
       $result2->bindParam(":uid",$uid);
       $result2->execute();
       $row2=$result2->fetch();
       if($row2)
       {
         echo json_encode(['status'=>'error','message'=>'Email already exists']);
         exit;
       }
       //check email exist end
 
       //check contact exist start
             $sql5="select * from user where contact=:contact and user_id!=:uid";
             $result3=$con->prepare($sql5);
             $result3->bindParam(":contact",$contact);
             $result3->bindParam(":uid",$uid);
             $result3->execute();
             $row3=$result3->fetch();
             if($row3)
             {
               echo json_encode(['status'=>'error','message'=>'Mobile no already exists']);
               exit;
             }
       //check contact exist end
 
 
       $_SESSION['uname']=$first_name." ".$last_name;
       $_SESSION['ugender']=$gender;

       $sql="update user set first_name=:first_name,last_name=:last_name,email=:email,contact=:contact,gender=:gender where user_id=:uid";
       $result=$con->prepare($sql);
       $result->bindParam(":first_name",$first_name);
       $result->bindParam(":last_name",$last_name);
       $result->bindParam(":email",$email);
       $result->bindParam(":contact",$contact);
       $result->bindParam(":gender",$gender);
       $result->bindParam(":uid",$uid);
 
       try
       {
         $result->execute();
         echo json_encode(['status'=>'success','message'=>'Profile Updated successfully']);
       }
       catch(Exception $e)
       {
         echo json_encode(['status'=>'error','message'=>'Error to Update Profile']);
       }
       
     }
     //update profile end


          //update profile admin start
          if($cmd=="update_profile_admin")
          {
            $first_name=strip_tags($_POST['first_name']);
            $last_name=strip_tags($_POST['last_name']);
            $email=strip_tags($_POST['email']);
            $contact=strip_tags($_POST['contact']);
            $gender=strip_tags($_POST['gender']);
            $uid=$_SESSION['aid'];
            
            //check email exist start
            $sql4="select * from admin where email=:email and user_id!=:uid";
            $result2=$con->prepare($sql4);
            $result2->bindParam(":email",$email);
            $result2->bindParam(":uid",$uid);
            $result2->execute();
            $row2=$result2->fetch();
            if($row2)
            {
              echo json_encode(['status'=>'error','message'=>'Email already exists']);
              exit;
            }
            //check email exist end
      
            //check contact exist start
                  $sql5="select * from admin where contact=:contact and user_id!=:uid";
                  $result3=$con->prepare($sql5);
                  $result3->bindParam(":contact",$contact);
                  $result3->bindParam(":uid",$uid);
                  $result3->execute();
                  $row3=$result3->fetch();
                  if($row3)
                  {
                    echo json_encode(['status'=>'error','message'=>'Mobile no already exists']);
                    exit;
                  }
            //check contact exist end
      
      
            $_SESSION['aname']=$first_name." ".$last_name;
            $_SESSION['agender']=$gender;
     
            $sql="update admin set first_name=:first_name,last_name=:last_name,email=:email,contact=:contact,gender=:gender where user_id=:uid";
            $result=$con->prepare($sql);
            $result->bindParam(":first_name",$first_name);
            $result->bindParam(":last_name",$last_name);
            $result->bindParam(":email",$email);
            $result->bindParam(":contact",$contact);
            $result->bindParam(":gender",$gender);
            $result->bindParam(":uid",$uid);
      
            try
            {
              $result->execute();
              echo json_encode(['status'=>'success','message'=>'Profile Updated successfully']);
            }
            catch(Exception $e)
            {
              echo json_encode(['status'=>'error','message'=>'Error to Update Profile']);
            }
            
          }
          //update profile admin end

    //user registration start
    if($cmd=="user_register")
    {
      $first_name=strip_tags($_POST['first_name']);
      $last_name=strip_tags($_POST['last_name']);
      $email=strip_tags($_POST['email']);
      $contact=strip_tags($_POST['contact']);
      $gender=strip_tags($_POST['gender']);
      $password=strip_tags($_POST['password']);  
      
      //check email exist start
      $sql4="select * from user where email=:email";
      $result2=$con->prepare($sql4);
      $result2->bindParam(":email",$email);
      $result2->execute();
      $row2=$result2->fetch();
      if($row2)
      {
        echo json_encode(['status'=>'error','message'=>'Email already exists']);
        exit;
      }
      //check email exist end

      //check contact exist start
            $sql5="select * from user where contact=:contact";
            $result3=$con->prepare($sql5);
            $result3->bindParam(":contact",$contact);
            $result3->execute();
            $row3=$result3->fetch();
            if($row3)
            {
              echo json_encode(['status'=>'error','message'=>'Mobile no already exists']);
              exit;
            }
      //check contact exist end


      $sql="insert into user (first_name,last_name,email,contact,gender,password) values (:first_name,:last_name,:email,:contact,:gender,:password)";
      $result=$con->prepare($sql);
      $result->bindParam(":first_name",$first_name);
      $result->bindParam(":last_name",$last_name);
      $result->bindParam(":email",$email);
      $result->bindParam(":contact",$contact);
      $result->bindParam(":gender",$gender);
      $result->bindParam(":password",$password);

      try
      {
        $result->execute();
        echo json_encode(['status'=>'success','message'=>'Registered successfully']);
      }
      catch(Exception $e)
      {
        echo json_encode(['status'=>'error','message'=>'Error to Register']);
      }
      
    }
    //user registration end

    //user login start
    if($cmd=="login_user")
    {
      $email=strip_tags($_POST['email']);
      $password=strip_tags($_POST['password']);  

      if(isset($_POST['remember_me']) && $_POST['remember_me']==1)
      {
        setcookie('myemail',$email,time()+(24*60*60),"/");
        setcookie('mypassword',$password,time()+(24*60*60),"/");
      }
      
      $sql4="select * from user where email=:email and password=:password";
      $result2=$con->prepare($sql4);
      $result2->bindParam(":email",$email);
      $result2->bindParam(":password",$password);
      $result2->execute();
      $row2=$result2->fetch();
      if($row2)
      {
        $_SESSION['uid']=$row2['user_id'];
        $_SESSION['uname']=$row2['first_name']." ".$row2['last_name'];
        $_SESSION['ugender']=$row2['gender'];
        echo json_encode(['status'=>'success','message'=>'Login Successfully']);
      }
      else
      {
        echo json_encode(['status'=>'error','message'=>'Email or password incorrect']);
      }
      
    }
    //user login end

        //change password start
        if($cmd=="change_password")
        {
          $user_id=$_SESSION['uid'];
          $current_password=strip_tags($_POST['current_password']);
          $new_password=strip_tags($_POST['new_password']);  
          
          $sql4="select * from user where user_id=:uid and password=:password";
          $result2=$con->prepare($sql4);
          $result2->bindParam(":uid",$user_id);
          $result2->bindParam(":password",$current_password);
          $result2->execute();
          $row2=$result2->fetch();
          if($row2)
          {
            
            //update pass start
            $sql5="update user set password=:password where user_id=:uid";
            $result3=$con->prepare($sql5);
            $result3->bindParam(":uid",$user_id);
            $result3->bindParam(":password",$new_password);
            try
            {
            $result3->execute();
            echo json_encode(['status'=>'success','message'=>'Password Updated Successfully']);
            }
            catch(Exception $e)
            {
              echo json_encode(['status'=>'success','message'=>'Error to Update Password']);
            }
            //update pass end

          }
          else
          {
            echo json_encode(['status'=>'error','message'=>'Current Password incorrect']);
          }
          
        }
        //change password end

    //admin login start
    if($cmd=="login_admin")
    {
      $email=strip_tags($_POST['email']);
      $password=strip_tags($_POST['password']);  
      
      $sql4="select * from admin where email=:email and password=:password";
      $result2=$con->prepare($sql4);
      $result2->bindParam(":email",$email);
      $result2->bindParam(":password",$password);
      $result2->execute();
      $row2=$result2->fetch();
      if($row2)
      {
        $_SESSION['aid']=$row2['user_id'];
        $_SESSION['aname']=$row2['first_name']." ".$row2['last_name'];
        $_SESSION['agender']=$row2['gender'];
        echo json_encode(['status'=>'success','message'=>'Login Successfully']);
      }
      else
      {
        echo json_encode(['status'=>'error','message'=>'Email or password incorrect']);
      }
      
    }
    //admin login end

    //admin change password start
    if($cmd=="change_password_admin")
    {
      $user_id=$_SESSION['aid'];
      $current_password=strip_tags($_POST['current_password']);
      $new_password=strip_tags($_POST['new_password']);  
      
      $sql4="select * from admin where user_id=:uid and password=:password";
      $result2=$con->prepare($sql4);
      $result2->bindParam(":uid",$user_id);
      $result2->bindParam(":password",$current_password);
      $result2->execute();
      $row2=$result2->fetch();
      if($row2)
      {
        
        //update pass start
        $sql5="update admin set password=:password where user_id=:uid";
        $result3=$con->prepare($sql5);
        $result3->bindParam(":uid",$user_id);
        $result3->bindParam(":password",$new_password);
        try
        {
        $result3->execute();
        echo json_encode(['status'=>'success','message'=>'Password Updated Successfully']);
        }
        catch(Exception $e)
        {
          echo json_encode(['status'=>'success','message'=>'Error to Update Password']);
        }
        //update pass end

      }
      else
      {
        echo json_encode(['status'=>'error','message'=>'Current Password incorrect']);
      }
      
    }
    //admin change password end

}

$con=null;

?>