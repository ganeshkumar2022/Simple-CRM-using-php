<?php
include_once 'session_check.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CRM - Quote details</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <?php
$url="http://localhost/crm/db.php?cmd=get_one_quote&id=".$_GET['id'];
$curl=curl_init();
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
curl_setopt($curl,CURLOPT_URL,$url);
$result=curl_exec($curl);

$response=json_decode($result,true);
curl_close($curl);
?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        include_once('sidebar.php');
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include_once("header.php");
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Quote details</h1>
                    </div>


                    <div class="row">
                       
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary"><?=$response['first_name']?>'s Quote Details</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                  <p><b>Name</b>&nbsp;&nbsp;&nbsp;&nbsp;<?=$response['first_name']?> <?=$response['last_name']?></p>
                                  <p><b>Email</b>&nbsp;&nbsp;&nbsp;&nbsp;<?=$response['email']?></p>
                                  <p><b>Contact no</b>&nbsp;&nbsp;&nbsp;&nbsp;<?=$response['contact']?> <?=$response['last_name']?></p>
                                  <p><b>Company</b>&nbsp;&nbsp;&nbsp;&nbsp;<?=$response['company']?></p>

                                  <p><b>Required Services :</b><br>
                                  <?php
                                  $ab=explode(",",$response['service_required']);
                                  foreach($ab as $data)
                                  {
                                    echo $data."<br/>";
                                  }
                                  ?>
                                  </p>
                                  <p><b>Description</b>&nbsp;&nbsp;&nbsp;&nbsp;<?=$response['description']?></p>
                                  <p><b>Remark</b>
                                  <form method="post" action="" id="profile_form">
                                    <input type="hidden" name="id" id="id" value="<?=$_GET['id']?>">
                                    <input type="hidden" name="cmd" id="cmd" value="quote_remark_update">
                                    <textarea class="form-control" name="remark" id="remark" rows="5"><?=$response['remark']?></textarea>
                                    <div class="text-danger remark_err"></div>
                                    <input type="submit" value="Submit" class="my-2 btn btn-primary">
                                  </form>
                                  </p>
                                </div>
                            </div>
                        </div>

                       
                    </div>

                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php
           include_once('footer.php');
           ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

<script>
    function number_exist(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
        return true; 
        }
        return false;
    }
    $(document).ready(function(){
        $("#profile_form").submit(function(e){
            e.preventDefault();

            var id=$("#id").val();
            var remark=$("#remark").val();
            var valid=true;
            var namepattern=/^[a-zA-Z\s]+$/;



            //remark validation start
            if(remark.length==0)
            {
               $(".remark_err").text('Please enter Remark');
               valid=false;   
            }
            else if(!namepattern.test(remark))
            {
                $(".remark_err").text('Remark pattern not valid.alphabets and space only allowed');
                valid=false;  
            }
            else
            {
                $(".remark_err").text('');
            }
            //remark validation end



            if(valid)
            {
                $.ajax({
                    url:"../db.php",
                    type:"POST",
                    data:$(this).serialize(),
                    dataType:'json',
                    success:function(response){
                        alert(response.message);
                        window.location.replace(window.location.href);
                        
                    },
                    error:function(xhr,status,response){
                        console.log(response);
                    }
                });
            }

        });
    });
</script>   

</body>

</html>