<?php
include_once 'session_check.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CRM - View Ticket</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">

<?php
$url="http://localhost/crm/db.php?cmd=view_one_ticket&id=".$_GET['id'];
$curl=curl_init();
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
curl_setopt($curl,CURLOPT_URL,$url);
$result=curl_exec($curl);

$response=json_decode($result,true);
curl_close($curl);

?>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        include_once('sidebar.php');
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include_once("header.php");
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Ticket Support</h1>
                    </div>


                    <div class="row">
                       
                        <!-- Area Chart -->
                        <div class="col-xl-8 col-lg-7">
                            <?php
                            foreach($response as $data)
                            {
                            ?>
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                    <span class="text-success">Ticket#<?=$data['ticket_id']?></span><br/>
                                    Subject : <?=$data['subject']?>
                                    <br/>
                                    Description : <?=$data['description']?>    
                                </h6>
                                     
                                    <p class="small">Created on : <?=$data['raised_at']?></p>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                 
                                <p><b>Response :</b>
                                  <form method="post" action="" class="profile_form">
                                    <input type="hidden" name="id" id="id" value="<?=$data['ticket_id']?>">
                                    <input type="hidden" name="cmd"  value="ticket_response_update">
                                    <textarea class="form-control" name="response" id="response" rows="5"><?=$data['response']?></textarea>
                                    <div class="text-danger response_err"></div>
                                    <input type="submit" value="Submit" class="my-2 btn btn-primary">
                                  </form>
                                  </p>
                                

                                </div>
                            </div>
                            <?php
                            }
                            ?>
                        </div>

                       
                    </div>

                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php
           include_once('footer.php');
           ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script>
    $(document).ready(function(){
        $(".profile_form").submit(function(e){
            e.preventDefault();

            var id=$("#id").val();
            var response=$("#response").val();
            var valid=true;
            var namepattern=/^[a-zA-Z\s]+$/;


            

            //response validation start
            if(response.length==0)
            {
               $(".response_err").text('Please enter response');
               valid=false;   
            }
            else if(!namepattern.test(response))
            {
                $(".response_err").text('response pattern not valid.alphabets and space only allowed');
                valid=false;  
            }
            else
            {
                $(".response_err").text('');
            }
            //response validation end



            if(valid)
            {
                $.ajax({
                    url:"../db.php",
                    type:"POST",
                    data:$(this).serialize(),
                    dataType:'json',
                    success:function(response){
                        alert(response.message);
                        window.location.replace('view_ticket.php');
                        
                    },
                    error:function(xhr,status,response){
                        console.log(response);
                    }
                });
            }

        });
    });
</script> 

</body>

</html>