<?php
include_once 'session_check.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>CRM - Manage Quote</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <?php
$url="http://localhost/crm/db.php?cmd=get_all_quotes";
$curl=curl_init();
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
curl_setopt($curl,CURLOPT_URL,$url);
$result=curl_exec($curl);

$response=json_decode($result,true);
curl_close($curl);
?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        include_once('sidebar.php');
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include_once("header.php");
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Manage Quote</h1>
                    </div>


                    <div class="row">
                       
                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">View all quotes</h6>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                               <table class="table table-bordered table-sm">
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Contact No</th>
                                    <th>Service Required</th>
                                    <th>Action</th>
                                </tr>
                                <?php
                                $i=1;
                                foreach($response as $data)
                                {
                                    ?>
                                    <tr>
                                        <td><?=$i?></td>
                                        <td><?=$data['first_name']." ".$data['last_name']?></td>
                                        <td><?=$data['email']?></td>
                                        <td><?=$data['contact']?></td>
                                        <td><?=$data['service_required']?></td>
                                        <td>
                                            <a href="quote_details.php?id=<?=$data['request_id']?>" class="btn btn-danger btn-sm">View</a>
                                        </td>
                                    </tr>
                                    <?php
                                    $i++;
                                }
                                ?>
                               </table>

                                </div>
                            </div>
                        </div>

                       
                    </div>

                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
           <?php
           include_once('footer.php');
           ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

<script>
    function number_exist(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
        return true; 
        }
        return false;
    }
    $(document).ready(function(){
        $("#profile_form").submit(function(e){
            e.preventDefault();

            var first_name=$("#first_name").val();
            var last_name=$("#last_name").val();
            var email=$("#email").val();
            var contact=$("#contact").val();
            var company=$("#company").val();
            var description=$("#description").val();
            var valid=true;
            var namepattern=/^[a-zA-Z\s]+$/;
            var emailpattern=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            var mobilepattern=/^\d{10}$/;
            const passwordPattern = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;

            const checkboxes = document.querySelectorAll('.service_required:checked');
            const values = Array.from(checkboxes).map(checkbox => checkbox.value);
            const concatenatedString = values.join(', ');


            //description validation start
            if(description.length==0)
            {
               $(".description_err").text('Please enter Description');
               valid=false;   
            }
            else if(!namepattern.test(description))
            {
                $(".description_err").text('Description pattern not valid.alphabets and space only allowed');
                valid=false;  
            }
            else
            {
                $(".description_err").text('');
            }
            //description validation end


            //service required start
            if(values.length==0)
            {
               $(".service_required_err").text('Please Choose services to continue');
               valid=false;   
            }
            else
            {
                $(".service_required_err").text('');
            }
            //service required end

            //company required start
            if(company.length==0)
            {
               $(".company_err").text('Please Enter company name');
               valid=false;   
            }
            else if(!namepattern.test(company))
            {
                $(".company_err").text('Company name format not valid');
                valid=false;  
            }
            else
            {
                $(".company_err").text('');
            }
            //company required end


            //first name validation start
            if(first_name.length==0)
            {
               $(".first_name_err").text('Please enter First name');
               valid=false;   
            }
            else if(!namepattern.test(first_name))
            {
                $(".first_name_err").text('First name pattern not valid');
                valid=false;  
            }
            else
            {
                $(".first_name_err").text('');
            }
            //first name validation end

            //last name validation start
            if(last_name.length==0)
            {
               $(".last_name_err").text('Please enter Last name');
               valid=false;   
            }
            else if(!namepattern.test(last_name))
            {
                $(".last_name_err").text('Last name pattern not valid');
                valid=false;  
            }
            else
            {
                $(".last_name_err").text('');
            }
            //last name validation end

            //email validation start
            if(email.length==0)
            {
               $(".email_err").text('Please enter email');
               valid=false;   
            }
            else if(!emailpattern.test(email))
            {
                $(".email_err").text('Please enter valid email');
                valid=false;  
            }
            else
            {
                $(".email_err").text('');
            }
            //email validation end

            //contact validation start
            if(contact.length==0)
            {
               $(".contact_err").text('Please enter Mobile no');
               valid=false;   
            }
            else if(!mobilepattern.test(contact))
            {
                $(".contact_err").text('Please enter valid Mobile no');
                valid=false;  
            }
            else
            {
                $(".contact_err").text('');
            }
            //contact validation end


            if(valid)
            {
                $.ajax({
                    url:"../db.php",
                    type:"POST",
                    data:$(this).serialize(),
                    dataType:'json',
                    success:function(response){
                        alert(response.message);
                        window.location.replace(window.location.href);
                        
                    },
                    error:function(xhr,status,response){
                        console.log(response);
                    }
                });
            }

        });
    });
</script>   

</body>

</html>